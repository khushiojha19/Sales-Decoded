use amazon_sales;

-- Q19 = What is the count of distinct customer types in the dataset?

select count(distinct customer_type) as cust_type
from data_amazon;






